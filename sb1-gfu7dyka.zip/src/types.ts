export interface Product {
  id: string;
  title: string;
  description: string;
  price: {
    original: number;
    discounted?: number;
  };
  rating: {
    value: number;
    count: number;
  };
  images: string[];
  featuredBadge?: {
    text: string;
    style: 'new' | 'sale' | 'featured';
  };
  countdown?: {
    endDate: Date;
  };
  socialProof: {
    recentSales: number;
    testimonials: Array<{
      text: string;
      author: string;
      rating: number;
    }>;
  };
}

export interface Settings {
  typography: {
    fontFamily: string;
    titleSize: string;
    descriptionSize: string;
    fontWeight: string;
    color: string;
  };
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  layout: {
    spacing: string;
    padding: string;
  };
  button: {
    text: string;
    backgroundColor: string;
    textColor: string;
    hoverBackgroundColor: string;
  };
  socialProof: {
    showRecentSales: boolean;
    showTestimonials: boolean;
  };
}

export type TabType = 'settings' | 'preview' | 'code';