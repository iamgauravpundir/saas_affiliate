import React from 'react';
import { Settings, Product } from '../../types';

interface SettingsTabProps {
  settings: Settings;
  onSettingsChange: (settings: Settings) => void;
  product: Product;
  onProductChange: (product: Product) => void;
}

export default function SettingsTab({
  settings,
  onSettingsChange,
  product,
  onProductChange,
}: SettingsTabProps) {
  const updateSettings = (path: string[], value: any) => {
    const newSettings = { ...settings };
    let current = newSettings;
    for (let i = 0; i < path.length - 1; i++) {
      current = current[path[i]];
    }
    current[path[path.length - 1]] = value;
    onSettingsChange(newSettings);
  };

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Typography Settings</h2>
        <div className="grid gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Font Family</label>
            <input
              type="text"
              value={settings.typography.fontFamily}
              onChange={(e) => updateSettings(['typography', 'fontFamily'], e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Title Size</label>
            <input
              type="text"
              value={settings.typography.titleSize}
              onChange={(e) => updateSettings(['typography', 'titleSize'], e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Color Settings</h2>
        <div className="grid gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Primary Color</label>
            <input
              type="color"
              value={settings.colors.primary}
              onChange={(e) => updateSettings(['colors', 'primary'], e.target.value)}
              className="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Secondary Color</label>
            <input
              type="color"
              value={settings.colors.secondary}
              onChange={(e) => updateSettings(['colors', 'secondary'], e.target.value)}
              className="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Button Settings</h2>
        <div className="grid gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Button Text</label>
            <input
              type="text"
              value={settings.button.text}
              onChange={(e) => updateSettings(['button', 'text'], e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Background Color</label>
            <input
              type="color"
              value={settings.button.backgroundColor}
              onChange={(e) => updateSettings(['button', 'backgroundColor'], e.target.value)}
              className="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Social Proof Settings</h2>
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              type="checkbox"
              checked={settings.socialProof.showRecentSales}
              onChange={(e) => updateSettings(['socialProof', 'showRecentSales'], e.target.checked)}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <label className="ml-2 block text-sm text-gray-900">Show Recent Sales</label>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              checked={settings.socialProof.showTestimonials}
              onChange={(e) => updateSettings(['socialProof', 'showTestimonials'], e.target.checked)}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <label className="ml-2 block text-sm text-gray-900">Show Testimonials</label>
          </div>
        </div>
      </div>
    </div>
  );
}