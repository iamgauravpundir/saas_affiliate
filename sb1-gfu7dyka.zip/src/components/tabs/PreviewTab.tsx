import React, { useState, useEffect } from 'react';
import { Settings, Product } from '../../types';
import { Star, ChevronLeft, ChevronRight, Tag, Check } from 'lucide-react';

interface PreviewTabProps {
  settings: Settings;
  product: Product;
}

export default function PreviewTab({ settings, product }: PreviewTabProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [buyerCount, setBuyerCount] = useState(156);

  useEffect(() => {
    if (product.countdown) {
      const interval = setInterval(() => {
        const now = new Date().getTime();
        const distance = new Date(product.countdown.endDate).getTime() - now;
        setTimeLeft(distance);
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [product.countdown]);

  useEffect(() => {
    const interval = setInterval(() => {
      setBuyerCount(prev => prev + 1);
    }, 15000); // Increment every 15 seconds

    return () => clearInterval(interval);
  }, []);

  const formatTime = (ms: number) => {
    const hours = Math.floor((ms % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((ms % (1000 * 60)) / 1000);
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
  };

  const features = [
    "Premium sound quality with deep bass",
    "Active noise cancellation",
    "30-hour battery life",
    "Quick charge capability",
    "Bluetooth 5.0 connectivity"
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="grid md:grid-cols-2 gap-8 p-6">
        {/* Left Column */}
        <div className="relative">
          {product.featuredBadge && (
            <div className="absolute top-4 left-4 z-10 bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2">
              <Tag className="w-4 h-4" />
              {product.featuredBadge.text}
            </div>
          )}
          
          <div className="relative aspect-square overflow-hidden rounded-lg">
            <img
              src={product.images[currentImageIndex]}
              alt={product.title}
              className="w-full h-full object-cover"
            />
            
            <button
              onClick={prevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 p-2 rounded-full shadow-md"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <button
              onClick={nextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 p-2 rounded-full shadow-md"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <div className="flex gap-2 mt-4">
            {product.images.map((image, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={`w-16 h-16 rounded-lg overflow-hidden border-2 ${
                  currentImageIndex === index ? 'border-blue-600' : 'border-transparent'
                }`}
              >
                <img src={image} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-gray-900">{product.title}</h1>
            <div className="flex items-center gap-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-5 h-5 ${
                      star <= product.rating.value
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600">
                ({product.rating.count})
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {product.price.discounted ? (
              <>
                <span className="text-2xl font-bold text-green-600">
                  ${product.price.discounted}
                </span>
                <span className="text-lg text-gray-500 line-through">
                  ${product.price.original}
                </span>
              </>
            ) : (
              <span className="text-2xl font-bold text-gray-900">
                ${product.price.original}
              </span>
            )}
          </div>

          <p className="text-gray-600">{product.description}</p>

          <div className="space-y-3">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-2">
                <Check className="w-5 h-5 text-green-500" />
                <span className="text-gray-700">{feature}</span>
              </div>
            ))}
          </div>

          {timeLeft > 0 && (
            <div className="text-center text-sm">
              <span className="text-gray-600">Deal ends in </span>
              <span className="font-medium">{formatTime(timeLeft)}</span>
            </div>
          )}

          <button
            style={{
              backgroundColor: settings.button.backgroundColor,
              color: settings.button.textColor,
            }}
            className="w-full py-3 px-6 rounded-lg font-semibold transition-colors duration-200 hover:opacity-90"
          >
            {settings.button.text}
          </button>

          <div className="flex items-center justify-center gap-2">
            <span className="inline-block w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            <span className="text-sm text-gray-600">
              {buyerCount} bought this product
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}