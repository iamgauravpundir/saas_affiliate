import React from 'react';
import { Settings, Product } from '../../types';
import { Copy } from 'lucide-react';

interface CodeExportTabProps {
  settings: Settings;
  product: Product;
}

export default function CodeExportTab({ settings, product }: CodeExportTabProps) {
  const generateHTML = () => {
    return `<!-- Product Showcase -->
<div class="product-showcase">
  <div class="product-grid">
    <!-- Left Column -->
    <div class="product-images">
      ${product.featuredBadge ? `
      <div class="featured-badge">
        ${product.featuredBadge.text}
      </div>
      ` : ''}
      
      <div class="main-image">
        <img src="${product.images[0]}" alt="${product.title}" />
      </div>
      
      <div class="thumbnail-gallery">
        ${product.images.map(image => `
        <button class="thumbnail">
          <img src="${image}" alt="" />
        </button>
        `).join('')}
      </div>
    </div>

    <!-- Right Column -->
    <div class="product-info">
      <h1>${product.title}</h1>
      
      <div class="price">
        ${product.price.discounted ? `
        <span class="discounted">$${product.price.discounted}</span>
        <span class="original">$${product.price.original}</span>
        ` : `
        <span class="regular">$${product.price.original}</span>
        `}
      </div>

      <div class="rating">
        <!-- Rating stars here -->
        <span>(${product.rating.count} reviews)</span>
      </div>

      <p class="description">${product.description}</p>

      <button class="cta-button">
        ${settings.button.text}
      </button>

      ${settings.socialProof.showRecentSales ? `
      <div class="social-proof">
        <p>${product.socialProof.recentSales} people bought this in the last 24 hours</p>
      </div>
      ` : ''}
    </div>
  </div>
</div>`;
  };

  const generateCSS = () => {
    return `/* Product Showcase Styles */
.product-showcase {
  font-family: ${settings.typography.fontFamily};
  max-width: 1200px;
  margin: 0 auto;
  padding: ${settings.layout.padding};
}

.product-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: ${settings.layout.spacing};
}

.featured-badge {
  position: absolute;
  top: 1rem;
  left: 1rem;
  background-color: ${settings.colors.primary};
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  font-weight: 600;
}

.main-image {
  position: relative;
  aspect-ratio: 1;
  overflow: hidden;
  border-radius: 0.5rem;
}

.main-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.thumbnail-gallery {
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
}

.thumbnail {
  width: 4rem;
  height: 4rem;
  border-radius: 0.375rem;
  overflow: hidden;
  cursor: pointer;
}

.product-info h1 {
  font-size: ${settings.typography.titleSize};
  color: ${settings.typography.color};
  margin-bottom: 1.5rem;
}

.cta-button {
  background-color: ${settings.button.backgroundColor};
  color: ${settings.button.textColor};
  width: 100%;
  padding: 1rem;
  border-radius: 0.5rem;
  font-weight: 600;
  transition: opacity 0.2s;
}

.cta-button:hover {
  opacity: 0.9;
}

/* Responsive Design */
@media (max-width: 768px) {
  .product-grid {
    grid-template-columns: 1fr;
  }
}`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">HTML Code</h2>
          <button
            onClick={() => copyToClipboard(generateHTML())}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
          >
            <Copy className="w-4 h-4" />
            Copy HTML
          </button>
        </div>
        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
          <code>{generateHTML()}</code>
        </pre>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">CSS Code</h2>
          <button
            onClick={() => copyToClipboard(generateCSS())}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
          >
            <Copy className="w-4 h-4" />
            Copy CSS
          </button>
        </div>
        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
          <code>{generateCSS()}</code>
        </pre>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Implementation Instructions</h2>
        <div className="prose max-w-none">
          <ol className="list-decimal list-inside space-y-2">
            <li>Copy the HTML code and paste it where you want the product showcase to appear</li>
            <li>Copy the CSS code and add it to your stylesheet</li>
            <li>Update the product images with your own image URLs</li>
            <li>Customize the content (product title, description, prices) as needed</li>
            <li>Adjust the styles by modifying the CSS variables to match your brand</li>
          </ol>
        </div>
      </div>
    </div>
  );
}