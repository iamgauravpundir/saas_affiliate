import React, { useState } from 'react';
import { Settings, Product, TabType } from '../types';
import SettingsTab from './tabs/SettingsTab';
import PreviewTab from './tabs/PreviewTab';
import CodeExportTab from './tabs/CodeExportTab';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/Tabs';
import { Settings2, Eye, Code } from 'lucide-react';

const defaultProduct: Product = {
  id: '1',
  title: 'Premium Wireless Headphones',
  description: 'Experience crystal-clear sound with our premium wireless headphones. Features active noise cancellation and 30-hour battery life.',
  price: {
    original: 299.99,
    discounted: 249.99
  },
  rating: {
    value: 4.5,
    count: 128
  },
  images: [
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800',
    'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800',
    'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800'
  ],
  featuredBadge: {
    text: 'Limited Time Offer',
    style: 'sale'
  },
  countdown: {
    endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  },
  socialProof: {
    recentSales: 47,
    testimonials: [
      {
        text: "Best headphones I've ever owned!",
        author: "Sarah M.",
        rating: 5
      },
      {
        text: "Great sound quality and comfortable fit.",
        author: "John D.",
        rating: 4
      }
    ]
  }
};

const defaultSettings: Settings = {
  typography: {
    fontFamily: 'Inter, system-ui, sans-serif',
    titleSize: '2rem',
    descriptionSize: '1rem',
    fontWeight: '600',
    color: '#1a1a1a'
  },
  colors: {
    primary: '#3b82f6',
    secondary: '#1e40af',
    accent: '#f59e0b'
  },
  layout: {
    spacing: '2rem',
    padding: '1.5rem'
  },
  button: {
    text: 'Get Deal Now',
    backgroundColor: '#3b82f6',
    textColor: '#ffffff',
    hoverBackgroundColor: '#1e40af'
  },
  socialProof: {
    showRecentSales: true,
    showTestimonials: true
  }
};

export default function ProductShowcase() {
  const [activeTab, setActiveTab] = useState<TabType>('preview');
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [product, setProduct] = useState<Product>(defaultProduct);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">
          Affiliate Product Showcase Builder
        </h1>
        
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as TabType)}>
          <TabsList className="mb-8">
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings2 className="w-4 h-4" />
              Settings
            </TabsTrigger>
            <TabsTrigger value="preview" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Preview
            </TabsTrigger>
            <TabsTrigger value="code" className="flex items-center gap-2">
              <Code className="w-4 h-4" />
              Export Code
            </TabsTrigger>
          </TabsList>

          <TabsContent value="settings">
            <SettingsTab
              settings={settings}
              onSettingsChange={setSettings}
              product={product}
              onProductChange={setProduct}
            />
          </TabsContent>

          <TabsContent value="preview">
            <PreviewTab settings={settings} product={product} />
          </TabsContent>

          <TabsContent value="code">
            <CodeExportTab settings={settings} product={product} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}