import React from 'react';
import ProductShowcase from './components/ProductShowcase';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <ProductShowcase />
    </div>
  );
}

export default App;